//
//  Custom Color.swift
//  The Aftermath
//
//  Created by measthmatic on 17/04/23.
//

import SwiftUI

let limeGreen = Color("limeGreen")
let black = Color("black")

extension UIColor {

    static let lime = UIColor(red: 155.0/255.0, green: 233.0/255.0, blue: 49.0/255.0, alpha: 1)

}
