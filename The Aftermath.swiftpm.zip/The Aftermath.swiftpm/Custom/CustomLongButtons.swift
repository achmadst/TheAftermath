//
//  CustomButtons.swift
//  The Aftermath
//
//  Created by measthmatic on 18/04/23.
//

import SwiftUI

struct CustomLongButtons: View {
    var buttonText = "My Button"
    var buttonColor = limeGreen
    
    var body: some View {
        ZStack {
            Rectangle()
                .frame(width: 1160, height: 64)
                .foregroundColor(buttonColor)
            
//            LeftCorner() //kanan bawah
//            LeftCorner() //kanan bawah
//                .trim(from: 0.493, to: 0.508)
//            .fill(black)
//                .frame(width: 1160, height: 64)
            
            LeftCorner() //kiri bawah
                .trim(from: 0.967, to: 0.981)
            .fill(black)
                .frame(width: 1160, height: 64)
            
            LeftCorner() //kanan atas
                .trim(from: 0.467, to: 0.481)
            .fill(black)
                .frame(width: 1160, height: 64)
            
            
            Text(buttonText)
                .font(Font(CustomFont.shared.bodyFont(size: 32)))
                .frame(width: 1160, height: 64)
        }
    }
}

struct LeftCorner: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.addRect(rect)
        return path
    }
}
struct CustomLongButtons_Previews: PreviewProvider {
    static var previews: some View {
        CustomLongButtons()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
