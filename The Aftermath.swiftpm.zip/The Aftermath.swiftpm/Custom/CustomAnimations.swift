//
//  SwiftUIView.swift
//  
//
//  Created by measthmatic on 20/04/23.
//

import SwiftUI

struct CustomAnimationsView: View {
    @State private var fadeInOut = false
    
    var body: some View {
        Image(systemName: "hand.tap")
            .resizable()
            .frame(width: 64, height: 64)
            .scaledToFit()
            .onAppear() {
                withAnimation(Animation.easeIn(duration: 2)
                    .repeatCount(8)) {
                        fadeInOut.toggle()
                            
                    }
                    
            }
            .opacity(fadeInOut ? 0 : 1)
            .offset(x: fadeInOut ? 200 : 0, y:0)
            .foregroundColor(limeGreen)
            
    }
}

struct CustomAnimationsView_Previews: PreviewProvider {
    static var previews: some View {
        CustomAnimationsView()
    }
}
