//
//  CustomFonts.swift
//  The Aftermath
//
//  Created by measthmatic on 16/04/23.
//
import SwiftUI

struct CustomFont {
    
    private init() {
        let bodyFontURL = Bundle.main.url(forResource: "Rajdhani-Medium", withExtension: "ttf")
        let titleFontURL = Bundle.main.url(forResource: "Rajdhani-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(bodyFontURL! as CFURL, CTFontManagerScope.process, nil)
        CTFontManagerRegisterFontsForURL(titleFontURL! as CFURL, CTFontManagerScope.process, nil)
//        print(UIFont.familyNames, "++++")
    }
    static let shared = CustomFont()
    
    func titleFont(size: CGFloat) -> UIFont {
        return UIFont(name: "Rajdhani-SemiBold", size: size)!
    }
    
    func bodyFont(size: CGFloat) -> UIFont {
        return UIFont(name: "Rajdhani-Medium", size: size)!
    }
}
