//
//  CustomShortButton.swift
//  The Aftermath
//
//  Created by measthmatic on 18/04/23.
//

import SwiftUI

struct CustomShortButtons: View {
    var buttonText = "My Button"
    var buttonColor = limeGreen
    
    var body: some View {
        ZStack {
            Rectangle()
                .frame(width: 480, height: 64)
                .foregroundColor(buttonColor)
            
//            LeftCorner() //kanan bawah
//                .trim(from: 0.493, to: 0.508)
//            .fill(black)
//                .frame(width: 1160, height: 64)
            
            LeftCorner() //kiri bawah
                .trim(from: 0.923, to: 0.962)
            .fill(black)
                .frame(width: 480, height: 64)
            
            LeftCorner() //kanan atas
                .trim(from: 0.423, to: 0.462)
            .fill(black)
                .frame(width: 480, height: 64)
            
            
            Text(buttonText)
                .font(Font(CustomFont.shared.bodyFont(size: 32)))
                .frame(width: 480, height: 64)
        }
    }
}


struct CustomShortButtons_Previews: PreviewProvider {
    static var previews: some View {
        CustomShortButtons()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}

