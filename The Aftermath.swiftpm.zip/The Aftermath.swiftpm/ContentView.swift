import SwiftUI
import UIKit

struct ContentView: View {
    
    
    @State var sigma = 21.0
    @State var rho = 32.0
    @State var beta = 10.0
    @State var dt = 0.01
    @State var isReset: Bool = false
    
    var body: some View {
        NavigationView {
            ZStack {
                Image("spaceBackground")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                
                LorenzAttractorView(sigma: $sigma, rho: $rho, beta: $beta, dt: $dt, isReset: $isReset)
                
                VStack(alignment: .center) {
                    VStack(alignment: .center) {
                        Text("Can you ever imagine")
                            .font(Font(CustomFont.shared.bodyFont(size: 48)))
                            .foregroundColor(limeGreen)
                        Text("The Aftermath (?)")
                            .font(Font(CustomFont.shared.titleFont(size: 108)))
                            .foregroundColor(limeGreen)
                    }
                    
                    Spacer()
                    HStack {
                        Image(systemName: "speaker.wave.2")
                        Text("Life Like - Alexi Action from Pixabay")
                            .font(Font(CustomFont.shared.bodyFont(size: 24)))
                    }
                    .foregroundColor(limeGreen)
                    NavigationLink (
                        destination: IntroductionOneView(),
                        label: {
                            CustomLongButtons(buttonText: "Start Your Journey")
                        })
                    .foregroundColor(.black)
                    .padding(.bottom, 80)
                }
                .padding(.top, 200)
            }
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}

struct Content_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
