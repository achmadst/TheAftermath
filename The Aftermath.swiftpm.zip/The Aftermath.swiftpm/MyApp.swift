import SwiftUI
import AVKit

@main
struct MyApp: App {
    var audioPlayer = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "lifelike-alexiaction", withExtension: "mp3")!)
    var body: some Scene {
        WindowGroup {
            ContentView()
                .onAppear{
                    audioPlayer.play()
                    audioPlayer.numberOfLoops = -1
                    audioPlayer.volume = 0.3
                }
        }
    }
}
