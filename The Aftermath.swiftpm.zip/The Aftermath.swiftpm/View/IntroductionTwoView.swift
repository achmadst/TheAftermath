//
//  IntroductionTwoView.swift
//  The Aftermath
//
//  Created by measthmatic on 16/04/23.
//

import SwiftUI

struct IntroductionTwoView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Image("spaceBackground")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                VStack(alignment: .leading) {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("The Butterfly Effect")
                            .font(Font(CustomFont.shared.titleFont(size: 96)))
                            .foregroundColor(limeGreen)
                        Text("""
    **is closely associated with the work of Edward Lorenz**, a mathematician and meteorologist who discovered that a minor change in input parameters can drastically change weather models.
    
    The equation of this models **is known as Lorenz Attractor**.
    """)
                        .font(Font(CustomFont.shared.bodyFont(size: 40)))
                        .foregroundColor(limeGreen)
                        
                    }
                    Spacer()
                    HStack {
                        Spacer()
                        NavigationLink(
                            destination: {
                                IntroductionThreeView()
                            },
                            label: {
                                CustomShortButtons(buttonText: "Next")
                                
                            })
                        .foregroundColor(black)
                        .padding(EdgeInsets(top: 0, leading: 0, bottom: 80, trailing: 0))
                    }
                }
                .padding(EdgeInsets(top: 150, leading: 100, bottom: 0, trailing: 80))
            }
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}

struct IntroductionTwoView_Previews: PreviewProvider {
    static var previews: some View {
        IntroductionTwoView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
