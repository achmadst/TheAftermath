//
//  IntroductionOneView.swift
//  The Aftermath
//
//  Created by measthmatic on 16/04/23.
//

import SwiftUI

struct IntroductionOneView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Image("spaceBackground")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                VStack(alignment: .leading) {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Do You Know?")
                            .font(Font(CustomFont.shared.titleFont(size: 96)))
                            .foregroundColor(limeGreen)
                        Text("""
    There is a concept that **a small change** in one state of a complex system **can result large differences** in a later state, it’s called **The Butterfly Effect**
    """)
                        .font(Font(CustomFont.shared.bodyFont(size: 40)))
                        .foregroundColor(limeGreen)
                        
                    }
                    
                    Spacer()
                    HStack {
                        Spacer()
                        NavigationLink(
                            destination: {
                                IntroductionTwoView()
                            },
                            label: {
                                CustomShortButtons(buttonText: "Next")
                                
                            })
                        .foregroundColor(black)
                        .padding(EdgeInsets(top: 0, leading: 0, bottom: 80, trailing: 0))
                    }
                }
                .padding(EdgeInsets(top: 150, leading: 100, bottom: 0, trailing: 80))
            }
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}

struct IntroductionOneView_Previews: PreviewProvider {
    static var previews: some View {
        IntroductionOneView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
