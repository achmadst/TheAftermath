//
//  SwiftUIView.swift
//  
//
//  Created by measthmatic on 18/04/23.
//

import SwiftUI
import SceneKit

struct VisualizeView: View {
    @State var sigma = 10.0
    @State var rho = 28.0
    @State var beta = 8.0/3.0
    @State var dt = 0.01
    @State var isReset: Bool = false
    @State private var fadeInOut: Bool = false
    
    var body: some View {
        NavigationView {
            ZStack {
                
                Image("spaceBackground")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                
                LorenzAttractorView(sigma: $sigma, rho: $rho, beta: $beta, dt: $dt, isReset: $isReset)
                
                Image(systemName: "hand.tap")
                    .resizable()
                    .frame(width: 48, height: 48)
                    .scaledToFit()
                    .onAppear() {
                        withAnimation(Animation.easeInOut(duration: 2)
                            .repeatCount(6)) {
                                fadeInOut.toggle()
                                    
                            }
                            
                    }
                    .opacity(fadeInOut ? 0 : 1)
                    .offset(x: fadeInOut ? 200 : 0, y:0)
                    .foregroundColor(limeGreen)
                    
                
                VStack(alignment: .leading) {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Lorenz Attractor")
                            .font(Font(CustomFont.shared.titleFont(size: 96)))
                            .foregroundColor(limeGreen)
                        Spacer()
                        
                    }
                    Spacer()
                    HStack(alignment: .bottom) {
                        VStack(alignment: .leading, spacing: 4){
                            Text("Customize Parameters")
                                .font(Font(CustomFont.shared.titleFont(size: 40)))
                                .foregroundColor(limeGreen)
                            VStack(alignment: .leading, spacing: 0) {
                                HStack {
                                    Text("Sigma (\u{03C3}):")
                                    Text("\(String(format: "%0.2f",sigma))")

                                }
                                Slider(value: $sigma, in: 0...30, onEditingChanged: { editing in
                                    if !editing{
                                        isReset.toggle()
                                    }
                                })
                                .accentColor(limeGreen)
                            }
                            
                            VStack(alignment: .leading, spacing: 0) {
                                HStack {
                                    Text("Rho (\u{03C1}):")
                                    Text("\(String(format: "%0.2f",rho))")
                                }
                                Slider(value: $rho, in: 20...50, onEditingChanged: { editing in
                                    if !editing{
                                        isReset.toggle()
                                    }
                                })
                                .accentColor(limeGreen)
                            }
                            

                            VStack(alignment: .leading, spacing: 0) {
                                HStack {
                                    Text("Beta (\u{03B2}):")
                                    Text("\(String(format: "%0.2f",beta))")
                                }
                                Slider(value: $beta, in: 0...16, onEditingChanged: { editing in
                                    if !editing{
                                        isReset.toggle()
                                    }
                                })
                                .accentColor(limeGreen)
                            }
                        }
                        .font(Font(CustomFont.shared.bodyFont(size: 28)))
                        .foregroundColor(limeGreen)
                        .padding(EdgeInsets(top: 0, leading: 0, bottom: 70, trailing: 40))
                        Spacer()
                        NavigationLink(
                            destination: {
                                ClosingView()
                            },
                            label: {
                                CustomShortButtons(buttonText: "Next")
                                
                            })
                        .foregroundColor(black)
                        .padding(EdgeInsets(top: 0, leading: 0, bottom: 80, trailing: 80))
                    }
                }
                .padding(EdgeInsets(top: 80, leading: 80, bottom: 0, trailing: 0))
            }
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}

struct VisualizeView_Previews: PreviewProvider {
    static var previews: some View {
        VisualizeView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
