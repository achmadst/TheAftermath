//
//  SwiftUIView.swift
//  
//
//  Created by measthmatic on 16/04/23.
//

import SwiftUI

struct IntroductionThreeView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Image("spaceBackground")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                VStack(alignment: .leading) {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Lorenz Attractor")
                            .font(Font(CustomFont.shared.titleFont(size: 96)))
                            .foregroundColor(limeGreen)
                        Text("""
    **can visualize The Butterfly Effect** from this equation:
    """)
                        .font(Font(CustomFont.shared.bodyFont(size: 40)))
                        .foregroundColor(limeGreen)
                        
                        Image("EquationGreen")
                            .resizable()
                            .frame(width: 300, height: 300)
                            .padding()
                        
                        Text("""
    **a small change** of parameter \u{03C3}, \u{03C1}, \u{03B2} in this equation, **can generate whole different visualization.**
    """)
                        .font(Font(CustomFont.shared.bodyFont(size: 40)))
                        .foregroundColor(limeGreen)
                        
                    }
                    Spacer()
                    HStack {
                        Spacer()
                        NavigationLink(
                            destination: {
                                VisualizeView()
                            },
                            label: {
                                CustomShortButtons(buttonText: "Visualize")
                                
                            })
                        .foregroundColor(black)
                        .padding(EdgeInsets(top: 0, leading: 0, bottom: 80, trailing: 0))
                    }
                }
                .padding(EdgeInsets(top: 150, leading: 100, bottom: 0, trailing: 80))
            }
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}


struct IntroductionThreeView_Previews: PreviewProvider {
    static var previews: some View {
        IntroductionThreeView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
