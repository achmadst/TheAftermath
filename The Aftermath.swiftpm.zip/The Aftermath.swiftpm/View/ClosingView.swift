//
//  ClosingView.swift
//  The Aftermath
//
//  Created by measthmatic on 19/04/23.
//

import SwiftUI

struct ClosingView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Image("spaceBackground")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                VStack(alignment: .leading) {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("As we can see")
                            .font(Font(CustomFont.shared.titleFont(size: 96)))
                            .foregroundColor(limeGreen)
                        Text("""
    this equation represent that **the aftermath of small action can trigger a chain reaction of events**. Just like real life, if we make a choice it will impact our future life.
    
    So we should always strive to make choices that align with our values and contribute to the greater good.
    """)
                        .font(Font(CustomFont.shared.bodyFont(size: 40)))
                        .foregroundColor(limeGreen)
                        
                    }
                    Spacer()
                    HStack {
                        Spacer()
                        NavigationLink(
                            destination: {
                                ContentView()
                            },
                            label: {
                                CustomShortButtons(buttonText: "Finish")
                                
                            })
                        .foregroundColor(black)
                        .padding(EdgeInsets(top: 0, leading: 0, bottom: 80, trailing: 0))
                    }
                }
                .padding(EdgeInsets(top: 150, leading: 100, bottom: 0, trailing: 80))
            }
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}

struct ClosingView_Previews: PreviewProvider {
    static var previews: some View {
        ClosingView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
