//
//  LorenzAttractorModel.swift
//  The Aftermath
//
//  Created by measthmatic on 18/04/23.
//

import SwiftUI
import SceneKit

struct LorenzAttractorView: UIViewRepresentable {
    @Binding var sigma: Double
    @Binding var rho: Double
    @Binding var beta: Double
    @Binding var dt: Double
    @Binding var isReset: Bool
    
    let sceneView = SCNView()
    let scene:SCNScene = SCNScene()
    //    var points: [SCNVector3]
    let  pointscolor = UIColor.lime
    @State var currentIndex = 0
    
    func lorenzAttractorPoints() -> [SCNVector3] {
        var x = 1.0
        var y = 0.0
        var z = 0.0
        var points: [SCNVector3] = []
        
        for _ in 0..<8000 {
            let dx = sigma * (y - x) * dt
            let dy = (x * (rho - z) - y) * dt
            let dz = (x * y - beta * z) * dt
            x += dx
            y += dy
            z += dz
            points.append(SCNVector3(x, y, z))
        }
        
        return points
    }
    

    
    func makeUIView(context: Context) -> SCNView {
//        let scene = SCNScene()
        sceneView.scene = scene
        sceneView.backgroundColor = UIColor.clear
        
        // Set up the camera
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 100)
        scene.rootNode.addChildNode(cameraNode)
        
        // Set up camera control
        sceneView.allowsCameraControl = true
        sceneView.defaultCameraController.interactionMode = .orbitTurntable
        sceneView.defaultCameraController.inertiaEnabled = true
//        sceneView.defaultCameraController.maximumVerticalAngle = 360
//        sceneView.defaultCameraController.minimumVerticalAngle = -360
        
        
        
        // Add the initial point
        addPoint(at: currentIndex, to: scene)
        
        // Set up a timer to add new points every 0.1 seconds
        Timer.scheduledTimer(withTimeInterval: 0.001, repeats: true) { timer in
            currentIndex += 1
            if currentIndex < lorenzAttractorPoints().count {
                addPoint(at: currentIndex, to: scene)
            } else {
                timer.invalidate()
            }
            
        }
        return sceneView
    }
    
    func updateUIView(_ uiView: SCNView, context: Context) {
        if isReset{
            uiView.scene?.rootNode.enumerateChildNodes { (node, stop) in
                node.removeFromParentNode()
            }
            isReset = false
        }
    }
    
    func addPoint(at index: Int, to scene: SCNScene) {
        let point = lorenzAttractorPoints()[index]
        // Create a new node for the point
        
        let sphere = SCNSphere(radius: 0.1)
        sphere.firstMaterial?.diffuse.contents = pointscolor
        let node = SCNNode(geometry: sphere)
        node.position = point
        
        // Add the node to the scene with an animation
        
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 0.1
        scene.rootNode.addChildNode(node)
        SCNTransaction.commit()
        
        
    }
}

